public interface IMessageService
{
    void SendMessage(string message);
}
