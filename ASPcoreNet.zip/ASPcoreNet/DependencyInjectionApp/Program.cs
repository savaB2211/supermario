﻿using Microsoft.Extensions.DependencyInjection;
using System;

var serviceProvider = new ServiceCollection()
    .AddSingleton<IMessageService, ConsoleMessageService>()
    .BuildServiceProvider();

var messageService = serviceProvider.GetRequiredService<IMessageService>();
messageService.SendMessage("Привет, ASP.NET Core DI!");

Console.ReadLine();
