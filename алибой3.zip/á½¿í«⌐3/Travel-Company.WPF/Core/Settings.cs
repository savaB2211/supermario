﻿using Travel_Company.WPF.Models;

namespace Travel_Company.WPF.Core;
//Настройки пользователя в приложении
public class Settings
{
    public bool IsAuthorized { get; set; } = false;
    public User? User { get; set; }  //Методы доступа
    public string UserName { get; set; } = string.Empty;
}

//get - возвращает значение свойства
//set-устанавливает значения свойства 