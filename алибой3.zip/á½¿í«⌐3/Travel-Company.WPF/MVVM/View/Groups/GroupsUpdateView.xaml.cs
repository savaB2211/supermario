﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Groups
{
    /// <summary>
    /// Interaction logic for GroupsUpdateView.xaml
    /// </summary>
    public partial class GroupsUpdateView : UserControl
    {
        public GroupsUpdateView()
        {
            InitializeComponent();
        }
    }
}
