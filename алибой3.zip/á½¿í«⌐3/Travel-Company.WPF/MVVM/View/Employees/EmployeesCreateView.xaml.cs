﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Employees
{
    /// <summary>
    /// Interaction logic for EmployeesCreateView.xaml
    /// </summary>
    public partial class EmployeesCreateView : UserControl
    {
        public EmployeesCreateView()
        {
            InitializeComponent();
        }
    }
}
