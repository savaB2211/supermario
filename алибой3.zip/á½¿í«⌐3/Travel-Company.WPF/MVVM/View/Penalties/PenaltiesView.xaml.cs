﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Penalties
{
    /// <summary>
    /// Interaction logic for PenaltiesView.xaml
    /// </summary>
    public partial class PenaltiesView : UserControl
    {
        public PenaltiesView()
        {
            InitializeComponent();
        }
    }
}
