﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Routes
{
    /// <summary>
    /// Interaction logic for RoutesCreateView.xaml
    /// </summary>
    public partial class RoutesCreateView : UserControl
    {
        public RoutesCreateView()
        {
            InitializeComponent();
        }
    }
}
