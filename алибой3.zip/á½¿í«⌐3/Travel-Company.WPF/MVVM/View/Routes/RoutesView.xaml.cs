﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Routes
{
    /// <summary>
    /// Interaction logic for RoutesView.xaml
    /// </summary>
    public partial class RoutesView : UserControl
    {
        public RoutesView()
        {
            InitializeComponent();
        }
    }
}
