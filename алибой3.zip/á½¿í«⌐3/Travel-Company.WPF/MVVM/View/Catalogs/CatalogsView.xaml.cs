﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Catalogs
{
    /// <summary>
    /// Interaction logic for CatalogsView.xaml
    /// </summary>
    public partial class CatalogsView : UserControl
    {
        public CatalogsView()
        {
            InitializeComponent();
        }
    }
}