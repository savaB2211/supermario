﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Clients
{
    /// <summary>
    /// Interaction logic for ClientsUpdateView.xaml
    /// </summary>
    public partial class ClientsUpdateView : UserControl
    {
        public ClientsUpdateView()
        {
            InitializeComponent();
        }
    }
}
