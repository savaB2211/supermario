﻿using Microsoft.AspNetCore.Mvc;

namespace YourAppName.Controllers
{
    // Контроллер для управления действиями на странице "Index", получения деталей пользователя и получения номера телефона
    public class PhonebookController : Controller
    {
        // Действие для отображения страницы "Index"
        public IActionResult Index()
        {
            // Возвращает контент с текстом "Index Page"
            return Content("Index Page");
        }

        // Действие для получения деталей пользователя по имени и возрасту
        public IActionResult GetUserDetails(string name, int age)
        {
            // Возвращает контент с текстом, содержащим имя и возраст пользователя
            return Content($"User Age: {age} \nUser Name: {name}");
        }

        // Действие для получения номера телефона
        public IActionResult GetPhoneNumber(string phone)
        {
            // Возвращает контент с текстом, содержащим номер телефона
            return Content($"Phone: {phone}");
        }
    }
}