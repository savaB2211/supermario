﻿using Microsoft.AspNetCore.Mvc;

namespace YourAppName.Controllers
{
    // Контроллер для управления действиями на домашней странице и странице "О нас"
    public class HomeController : Controller
    {
        // Действие для отображения домашней страницы
        public IActionResult Index()
        {
            // Возвращает контент с текстом "Home Page"
            return Content("Home Page");
        }

        // Действие для отображения страницы "О нас"
        public IActionResult About()
        {
            // Возвращает контент с текстом "About Page"
            return Content("About Page");
        }
    }
}