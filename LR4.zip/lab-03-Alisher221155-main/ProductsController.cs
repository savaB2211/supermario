﻿using Microsoft.AspNetCore.Mvc;

namespace YourAppName.Controllers
{
    // Контроллер для управления действиями на странице "Products" и отображения деталей продукта
    public class ProductsController : Controller
    {
        // Действие для отображения страницы "Products"
        public IActionResult Index()
        {
            // Возвращает контент с текстом "Products Page"
            return Content("Products Page");
        }

        // Действие для отображения деталей продукта по его идентификатору
        public IActionResult Details(int id)
        {
            // Возвращает контент с текстом, содержащим идентификатор продукта
            return Content($"Details of product with ID: {id}");
        }
    }
}