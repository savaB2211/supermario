﻿using Microsoft.AspNetCore.Mvc;

namespace YourAppName.Controllers
{
    // Контроллер для управления действиями на странице "Index", "Users" и "UserDetails"
    public class NewController : Controller
    {
        // Действие для отображения страницы "Index"
        public IActionResult Index()
        {
            // Возвращает контент с текстом "Index Page"
            return Content("Index Page");
        }

        // Действие для отображения страницы "Users"
        public IActionResult Users()
        {
            // Возвращает контент с текстом "Users Page"
            return Content("Users Page");
        }

        // Действие для отображения деталей пользователя с определенным идентификатором
        public IActionResult UserDetails(string id)
        {
            // Возвращает контент с текстом, содержащим идентификатор пользователя
            return Content($"User Id: {id}");
        }
    }
}