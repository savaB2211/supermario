var builder = WebApplication.CreateBuilder(args);

// Добавление сервисов в контейнер
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Настройка конвейера HTTP-запросов
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting(); // Поместить UseRouting() перед UseEndpoints()
app.UseAuthorization();

// Настройка конечных точек маршрутизации
app.UseEndpoints(endpoints =>
{
    // Маршрут для получения деталей пользователя по идентификатору
    endpoints.MapControllerRoute(
        name: "users",
        pattern: "users/{id?}",
        defaults: new { controller = "New", action = "UserDetails" });

    // Маршрут для получения деталей пользователя по имени и возрасту
    endpoints.MapControllerRoute(
        name: "usersWithNameAndAge",
        pattern: "users/{name}/{age}",
        defaults: new { controller = "New", action = "UserDetailsWithNameAndAge" });

    // Маршрут для получения номера телефона
    endpoints.MapControllerRoute(
        name: "phonebook",
        pattern: "phonebook/{phone:regex(^7-\\d{{3}}-\\d{{3}}-\\d{{4}}$)}/",
        defaults: new { controller = "Phonebook", action = "GetPhoneNumber" });

    // Маршрут по умолчанию
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}");
});

app.Run();

