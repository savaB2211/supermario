using ConsoleAppWithDI.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;

namespace ConsoleAppWithDI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using IHost host = Startup.BuildHost();
            var greetingService = host.Services.GetRequiredService<IGreetingService>();

            Console.Write("������� ���� ���: ");
            string name = Console.ReadLine();
            greetingService.Greet(name);
        }
    }
}
