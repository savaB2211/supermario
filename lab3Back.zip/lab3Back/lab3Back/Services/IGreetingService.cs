﻿namespace ConsoleAppWithDI.Services
{
    public interface IGreetingService
    {
        void Greet(string name);
    }
}
