﻿using Microsoft.Extensions.Logging;

namespace ConsoleAppWithDI.Services
{
    public class GreetingService : IGreetingService
    {
        private readonly ILogger<GreetingService> _logger;

        public GreetingService(ILogger<GreetingService> logger)
        {
            _logger = logger;
        }

        public void Greet(string name)
        {
            _logger.LogInformation($"Привет, {name}! Добро пожаловать в консольное приложение с DI.");
        }
    }
}
