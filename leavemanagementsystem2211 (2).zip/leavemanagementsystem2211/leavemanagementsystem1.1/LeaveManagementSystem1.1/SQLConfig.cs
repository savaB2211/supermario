﻿// Подключение необходимых пространств имен для работы с MySQL, Windows Forms, и управления данными.
using System; 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient; // Для взаимодействия с MySQL.
using System.Data; // Для работы с данными (DataTable, DataSet и т.д.).
using System.Windows.Forms; // Для использования элементов управления Windows Forms.

namespace LeaveManagementSystem1._1
{
    // Класс SQLConfig предоставляет методы для работы с базой данных MySQL.
    class SQLConfig
    {
        // Создаем объект подключения к базе данных с параметрами соединения.
        private MySqlConnection con = new MySqlConnection(
            "server=localhost;user id=root;password=;database=db_leave;sslMode=none;charset=utf8mb4;"
        ); 
        // Сервер: localhost, пользователь: root, без пароля, база данных: db_leave.

        private MySqlCommand cmd; // Объект для выполнения SQL-запросов.
        private MySqlDataAdapter da; // Объект для заполнения таблиц данными из базы.
        public DataTable dt; // Таблица для хранения результатов запросов.
        int result; // Переменная для хранения результата операций SQL.
        usableFunction funct = new usableFunction(); // Вспомогательный класс для пользовательских функций.

        // Метод для выполнения операций CUD (Create, Update, Delete).
        public void Execute_CUD(string sql, string msg_false, string msg_true)
        {
            try // Блок проверки на наличие ошибок.
            {
                con.Open(); // Открываем соединение с базой данных.
                cmd = new MySqlCommand(); // Создаем объект команды.
                cmd.Connection = con; // Привязываем команду к соединению.
                cmd.CommandText = sql; // Устанавливаем текст SQL-запроса.
                result = cmd.ExecuteNonQuery(); // Выполняем запрос (возвращает количество затронутых строк).

                if (result > 0) // Если запрос затронул строки.
                {
                    MessageBox.Show(msg_true); // Показываем сообщение об успешной операции.
                }
                else // Если запрос не затронул строки.
                {
                    MessageBox.Show(msg_false); // Показываем сообщение об ошибке.
                }
            }
            catch (Exception ex) // Обработка исключений.
            {
                MessageBox.Show(ex.Message); // Выводим сообщение об ошибке.
            }
            finally
            {
                con.Close(); // Закрываем соединение (всегда выполняется).
            }
        }

        // Метод для выполнения SQL-запроса, не возвращающего результат (например, INSERT/UPDATE).
        public void Execute_Query(string sql)
        {
            try
            {
                con.Open(); // Открываем соединение.
                cmd = new MySqlCommand(); // Создаем команду.
                cmd.Connection = con; // Привязываем команду к соединению.
                cmd.CommandText = sql; // Устанавливаем SQL-запрос.
                result = cmd.ExecuteNonQuery(); // Выполняем запрос.
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); // Показываем ошибку.
            }
            finally
            {
                con.Close(); // Закрываем соединение.
            }
        }

        // Метод для загрузки данных в DataGridView.
        public void Load_DTG(string sql, DataGridView dtg)
        {
            try
            {
                if (con.State != ConnectionState.Open) // Проверяем, открыто ли соединение.
                {
                    con.Open(); // Открываем соединение.
                }
                cmd = new MySqlCommand(); // Создаем команду.
                da = new MySqlDataAdapter(); // Создаем адаптер.
                dt = new DataTable(); // Создаем объект DataTable.

                cmd.Connection = con; // Привязываем команду к соединению.
                cmd.CommandText = sql; // Устанавливаем SQL-запрос.
                da.SelectCommand = cmd; // Привязываем адаптер к команде.
                da.Fill(dt); // Заполняем DataTable данными из базы.
                dtg.DataSource = dt; // Привязываем DataTable к DataGridView.

                // Дополнительная настройка отображения данных.
                funct.ResponsiveDtg(dtg); // Вызываем метод для настройки отображения.
                dtg.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Подгоняем столбцы по ширине.
                dtg.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells; // Подгоняем строки по высоте.
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); // Выводим сообщение об ошибке.
            }
            finally
            {
                da.Dispose(); // Освобождаем ресурсы адаптера.
                con.Close(); // Закрываем соединение.
            }
        }

        // Остальные методы аналогично — добавлю комментарии для одного из них.

        // Метод для загрузки данных в ComboBox.
        public void fiil_CBO(string sql, ComboBox cbo)
        {
            try
            {
                if (con.State != ConnectionState.Open) // Проверяем соединение.
                {
                    con.Open(); // Открываем соединение.
                }
                cmd = new MySqlCommand(); // Создаем команду.
                da = new MySqlDataAdapter(); // Создаем адаптер.
                dt = new DataTable(); // Создаем DataTable.

                cmd.Connection = con; // Привязываем команду к соединению.
                cmd.CommandText = sql; // Устанавливаем SQL-запрос.
                da.SelectCommand = cmd; // Привязываем адаптер к команде.
                da.Fill(dt); // Заполняем DataTable.

                cbo.DataSource = dt; // Устанавливаем источник данных для ComboBox.
                cbo.ValueMember = dt.Columns[0].ColumnName; // Значение для каждой строки (из первого столбца).
                cbo.DisplayMember = dt.Columns[1].ColumnName; // Отображаемое значение (из второго столбца).
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); // Выводим сообщение об ошибке.
            }
            finally
            {
                con.Close(); // Закрываем соединение.
                da.Dispose(); // Освобождаем ресурсы адаптера.
            }
        }

        // Остальные методы имеют схожую структуру — комментарии можно повторить с учетом их специфики.
    }
}
